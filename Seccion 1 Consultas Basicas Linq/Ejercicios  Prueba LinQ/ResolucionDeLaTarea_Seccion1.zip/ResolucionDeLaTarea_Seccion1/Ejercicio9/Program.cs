﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio9
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             string[] words = { "blueberry", "chimpanzee", "abacus", "banana", "apple", "cheese" };

Crear una consulta LinQ que permita agrupar de forma alfabética las siguientes palabras:



La salida deberá de tener el siguiente formato:

***********************************************

Empieza con a

- abacus

-apple

Empieza con b

-blueberry

-banana

Empieza con c

-chimpanzee

-cheese
             
             */
            string[] words = { "blueberry", "chimpanzee", "abacus", "banana", "apple", "cheese" };
            var wordsList = from word in words
                            group word by word[0] into primeraLetra
                            select primeraLetra;
            foreach(var primer in wordsList)
            {
                Console.WriteLine("Empieza con "+primer.Key);
                foreach(var element in primer)
                {
                    Console.WriteLine("-"+element);
                }
            }
            Console.Read();

        }
    }
}
