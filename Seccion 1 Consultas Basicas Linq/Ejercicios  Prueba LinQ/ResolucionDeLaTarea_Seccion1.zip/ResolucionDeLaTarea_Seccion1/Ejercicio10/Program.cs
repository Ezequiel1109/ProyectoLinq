﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio10
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             10  Se tiene la siguiente el siguiente arreglo:

string[] words2 = { "blueberry", "chimpanzee", "abacus", "banana", "apple", "cheese", "elephant", "umbrella", "anteater" };

Agrupar solo las palabras que inician con una vocal:



La salida debe ser de la siguiente forma:

/* Output:

Inician con la vocal: a

abacus

apple

anteater

Inician con la vocal e

elephant

Inician con la vocalu

umbrella */
            string[] words2 = { "blueberry", "chimpanzee", "abacus", "banana", "apple", "cheese", "elephant", "umbrella", "anteater" };
            var words2List = from array in words2
                             group array by array[0] into val
                             where val.Key == 'a' || val.Key == 'e'
                             || val.Key=='i' || val.Key=='o'||
                             val.Key=='u'
                             select val;
            foreach(var lista in words2List)
            {
                Console.WriteLine("Inician con la vocal "+lista.Key);
                foreach(var element in lista)
                {
                    Console.WriteLine(element);
                }
            }
            Console.Read();

        }
    }
}
