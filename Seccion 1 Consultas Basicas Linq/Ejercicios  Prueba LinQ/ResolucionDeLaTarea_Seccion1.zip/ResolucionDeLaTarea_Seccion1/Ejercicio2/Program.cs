﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             2. Se tiene el siguiente array
              int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
              Hacer una consulta LinQ e imprimir los números pares.
             */
            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var numbersQuery = from number in numbers
                               where number % 2 == 0
                               select number;
            foreach(var num in numbersQuery)
            {
                Console.WriteLine(num);
            }
            Console.Read();
        }
    }
}
