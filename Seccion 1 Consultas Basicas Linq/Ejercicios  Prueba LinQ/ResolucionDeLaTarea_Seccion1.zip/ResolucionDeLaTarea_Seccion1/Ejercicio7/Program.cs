﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio7
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             Question 7
7.Crear la siguiente clase:

public class Student {

public string First { get; set; }

public string Last { get; set; }

public int ID { get; set; }

}
Escribir en el main , lo siguiente:

List<Student> students = new List<Student> {

new Student {First="Svetlana", Last="Omelchenko", ID=111},

new Student {First="Claire", Last="O'Donnell", ID=112},

new Student {First="Sven", Last="Mortensen", ID=113},

new Student {First="Cesar", Last="Garcia", ID=114},

new Student {First="Debra", Last="Garcia", ID=115}

};
             */
            List<Student> students = new List<Student> {
            new Student {First="Svetlana", Last="Omelchenko", ID=111},
            new Student {First="Claire", Last="O'Donnell", ID=112},
            new Student {First="Sven", Last="Mortensen", ID=113},
            new Student {First="Cesar", Last="Garcia", ID=114},
            new Student {First="Debra", Last="Garcia", ID=115}
            };
            //Forma 1
            var sudentsList = from student in students
                              orderby student.Last ascending
                              select student;
            Console.WriteLine("Forma 1");
            foreach (var student in sudentsList)
            {
                Console.WriteLine(" Mi nombre es " + student.First + " y mi apellido es  " + student.Last);
            }
            //Forma 2
            Console.WriteLine("Forma 2");
            var sudentsList2 = from student in students
                              orderby student.Last ascending
                              select " Mi nombre es " + student.First + " y mi apellido es  " + student.Last;
            foreach(var element in sudentsList2)
            {
                Console.WriteLine(element);
            }
            Console.Read();

        }
    }
}
