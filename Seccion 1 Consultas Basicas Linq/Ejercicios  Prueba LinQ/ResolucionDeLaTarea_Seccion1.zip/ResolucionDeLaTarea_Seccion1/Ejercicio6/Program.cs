﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio6
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             6. Se tiene el siguiente array :
             int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
             Imprimir aquellos que sean menores que 5 y multiplos de 2 , usando una consulta LinQ.             
             */
            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var numbersList = from number in numbers
                              where number < 5 && number % 2 == 0
                              select number;
            foreach(var element in numbersList)
            {
                Console.WriteLine(element);
            }
            Console.Read();

        }
    }
}
