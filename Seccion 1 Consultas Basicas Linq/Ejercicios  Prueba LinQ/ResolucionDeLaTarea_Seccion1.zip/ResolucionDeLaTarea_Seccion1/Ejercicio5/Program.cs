﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             5. Se tiene el siguiente array:
              int[] scores = { 18, 25, 19, 16, 21, 80 };
              Obtener el  numero de elementos que cumplen con ser mayor a 20 , usando una consulta LinQ
             */
            int[] scores = { 18, 25, 19, 16, 21, 80 };
            var scoresList = from score in scores
                             where score > 20
                             select score;
            int numero = scoresList.Count();
            Console.WriteLine("El numero de elementos que cumplen son : " + numero);
            Console.Read();


        }
    }
}
