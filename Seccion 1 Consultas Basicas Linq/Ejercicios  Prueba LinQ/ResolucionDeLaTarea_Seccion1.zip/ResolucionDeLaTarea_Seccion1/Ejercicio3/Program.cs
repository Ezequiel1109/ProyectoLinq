﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             3.  Se tiene el siguiente array.
              string[] fruits = { "cherry", "apple", "blueberry" };
              Hacer una consulta linQ y ordenar de forma ascendente y de forma descendente.
             */
            //Ascendente
            string[] fruits = { "cherry", "apple", "blueberry" };
            var fruitsAsc = from fruit in fruits
                            orderby fruit ascending
                            select fruit;
            Console.WriteLine("Ascendente");
            foreach (var element in fruitsAsc)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("Descendente");
            var fruitsDesc = from fruit in fruits
                            orderby fruit descending
                            select fruit;

            foreach (var element in fruitsDesc)
            {
                Console.WriteLine(element);
            }
            Console.Read();
        }
    }
}
