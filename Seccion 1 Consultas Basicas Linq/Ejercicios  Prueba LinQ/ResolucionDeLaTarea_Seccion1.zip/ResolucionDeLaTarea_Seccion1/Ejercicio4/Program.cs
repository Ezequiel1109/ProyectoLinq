﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             4. Se tiene el siguiente array:
               int[] scores = { 90, 71, 82, 93, 75, 82 };
               Obtener el mayor score usando una consulta LinQ
             */
            int[] scores = { 90, 71, 82, 93, 75, 82 };
            var scoresList = from score in scores
                             select score;
            int mayor = scoresList.Max();
            Console.WriteLine("El mayor es : " + mayor);
            Console.Read();
        }
    }
}
