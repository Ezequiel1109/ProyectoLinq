﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal
{
   public class Funcion
    {
        public int idFuncion { get; set; }
        public DateTime fechaFuncion { get; set; }
    }
}
