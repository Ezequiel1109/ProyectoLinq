﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal
{
   public class TipoEntrada
    {
        public int IDTIPOENTRADA { get; set; }
        public string NOMBRE { get; set; }
    }
}
