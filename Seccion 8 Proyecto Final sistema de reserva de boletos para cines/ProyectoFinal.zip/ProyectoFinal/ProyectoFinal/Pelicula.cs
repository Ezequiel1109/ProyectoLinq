﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal
{
   public class Pelicula
    {
        public int idPelicula { get; set; }
        public string titulo { get; set; }
    }
}
