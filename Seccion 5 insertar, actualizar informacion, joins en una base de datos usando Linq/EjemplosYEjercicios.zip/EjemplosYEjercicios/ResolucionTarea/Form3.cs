﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            PruebaDataContext bd = new PruebaDataContext();
            int id = int.Parse(txtid.Text);
            //primero verificamos que no exista el ID en la BD
            int numero = (from region in bd.Regions
              where region.RegionID.Equals(id) select region).Count();
            if (numero == 1){
                MessageBox.Show("Ya existe ese ID");
                return;
            }
            //preparamos el objeto para registrar
            Region reg = new Region{ RegionID = id, RegionDescription = txtnombre.Text };
            bd.Regions.InsertOnSubmit(reg);
            try
            {
                bd.SubmitChanges();
                MessageBox.Show("Se guardo correctamente");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocurrio un error");
            }
        }
    }
}
