﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Form1_Load(object sender, EventArgs e)
        {
            var consulta = from region in bd.Regions
                join territory in bd.Territories
                on region.RegionID equals territory.RegionID
                select new { nombreTer = territory.TerritoryDescription, nombreRegion = region.RegionDescription };
            dgvTerritorios.DataSource = consulta;
        }
    }
}
