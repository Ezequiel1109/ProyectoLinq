﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Form6_Load(object sender, EventArgs e)
        {
            listar();
        }

        private void listar()
        {
            dgvRegion.DataSource = bd.Regions;
        }

        private void obtenerDatos(object sender, DataGridViewCellEventArgs e)
        {
            string id = dgvRegion.CurrentRow.Cells[0].Value.ToString();
            string nombre = dgvRegion.CurrentRow.Cells[1].Value.ToString();
            txtID.Text = id;
            txtNombre.Text = nombre;
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            //Primero recuperamos esa fila desde la base datos
            string id = txtID.Text;
            string nombre = txtNombre.Text;
            if (txtNombre.Text.Equals("")){
                errRegion.SetError(txtNombre,"Se debe de ingresar el nombre");
                return;
            }else{
                errRegion.SetError(txtNombre, "");
            }
            var consulta = bd.Regions.Where(p => p.RegionID.Equals(id));
            //Recorremos y modificaremos los datos
            foreach(Region reg in consulta)
            {
                reg.RegionDescription = nombre;
            }
            //Ahora actualizamos
            try
            {
                bd.SubmitChanges();
                listar();
                MessageBox.Show("Se actualizo correctamente");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocurrio entror");
            }
        }
    }
}
