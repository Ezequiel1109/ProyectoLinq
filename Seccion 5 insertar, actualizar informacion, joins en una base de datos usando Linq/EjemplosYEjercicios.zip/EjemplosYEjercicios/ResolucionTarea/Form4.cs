﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Form4_Load(object sender, EventArgs e)
        {
            listar();
        }
        public void listar()
        {
            dgvEmpleado.DataSource =
                bd.Suppliers.Select(x =>
                
                   new { x.CompanyName, x.ContactName, x.ContactTitle, x.Address , x.City }
                );
        }
        public void limpiarCampos()
        {
            txtAddress.Text = "";
            txtCity.Text = "";
            txtCompanyName.Text = "";
            txtContactName.Text = "";
            txtContactTitle.Text = "";
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string companyName = txtCompanyName.Text;
            string contactName = txtContactName.Text;
            string contactTitle = txtContactTitle.Text;
            string address = txtAddress.Text;
            string city = txtCity.Text;
            //validamos queno exista ya el nombre de la compañia
            int ncompany = (from item in bd.Suppliers
                            where item.CompanyName.Equals(companyName)
                            select item).Count();
            if (ncompany == 1)
            {
                MessageBox.Show("Ya existe en la base de datos");
                return;
            }
            //
            Supplier oSupplier = new Supplier
            {
                CompanyName= companyName,
                ContactName= contactName,
                ContactTitle= contactTitle,
                Address= address,
                City=city
            };
            bd.Suppliers.InsertOnSubmit(oSupplier);
            try
            {
                bd.SubmitChanges();
                listar();
                limpiarCampos();
                MessageBox.Show("Se registro correctamente");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocurrio un error");
            }
          
        }
    }
}
