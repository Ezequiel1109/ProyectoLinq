﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        public void listar()
        {
            dgvProducto.DataSource = bd.Products.Select(
              p => new { p.ProductName, p.QuantityPerUnit,
                  p.UnitPrice, p.UnitsInStock , p.CategoryID, p.SupplierID
              });
        }
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string nombre = txtnombre.Text;
            string descripcion = txtdescripcion.Text;
            decimal precio = txtprecio.Value;
            short stock = short.Parse(txtstock.Value.ToString());
            int idCat = (int)cboCategoria.SelectedValue;
            int idProv = (int)cboProveedor.SelectedValue;
            //Nombre
            if (txtnombre.Text.Equals("")){
                errorProducto.SetError(txtnombre, "El nombre es obligatorio");
                return;
            }
            else
                errorProducto.SetError(txtnombre, "");

            //Descripcion
            if (txtdescripcion.Text.Equals("")){
                errorProducto.SetError(txtdescripcion, "La descripcion es obligatorio");
                return;
            }
            else
                errorProducto.SetError(txtdescripcion, "");

            Product oProduct = new Product
            {
                ProductName = nombre,QuantityPerUnit = descripcion,UnitPrice = precio,
                UnitsInStock = stock,CategoryID = idCat,SupplierID = idProv
            };
            int numeroProducto = bd.Products.Where(p => p.ProductName.Equals(nombre)).Count();

            if (numeroProducto == 1){
                MessageBox.Show("El nombre del producto ya existe");
                return;
            }
            bd.Products.InsertOnSubmit(oProduct);
            try
            {
                bd.SubmitChanges();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocurrio un error");
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            listar();
            cboCategoria.DataSource = bd.Categories;
            cboCategoria.DisplayMember = "CategoryName";
            cboCategoria.ValueMember = "CategoryID";
            cboProveedor.DataSource = bd.Suppliers;
            cboProveedor.DisplayMember = "CompanyName";
            cboProveedor.ValueMember = "SupplierID";
        }
    }
}
