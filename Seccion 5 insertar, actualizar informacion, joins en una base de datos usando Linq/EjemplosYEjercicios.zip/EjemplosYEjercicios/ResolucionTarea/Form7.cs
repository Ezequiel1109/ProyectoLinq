﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void listar()
        {
            dgvProducto.DataSource = bd.Products.Select(x => new
            {
                x.ProductID,
                x.ProductName,
                x.CategoryID,
                x.SupplierID,
                x.UnitPrice,
                x.UnitsInStock
            });
        }
        private void Form7_Load(object sender, EventArgs e)
        {
            listar();
            cboCategoria.DataSource = bd.Categories;
            cboCategoria.DisplayMember = "CategoryName";
            cboCategoria.ValueMember = "CategoryID";
            cboProveedor.DataSource = bd.Suppliers;
            cboProveedor.ValueMember = "SupplierID";
            cboProveedor.DisplayMember = "CompanyName";
        }

        private void obtenerDatos(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text= dgvProducto.CurrentRow.Cells[0].Value.ToString();
            txtnombre.Text = dgvProducto.CurrentRow.Cells[1].Value.ToString();
            cboCategoria.SelectedValue = dgvProducto.CurrentRow.Cells[2].Value;
            cboProveedor.SelectedValue = dgvProducto.CurrentRow.Cells[3].Value;
            txtprecio.Value= (decimal)dgvProducto.CurrentRow.Cells[4].Value;
            txtstock.Value = (decimal)dgvProducto.CurrentRow.Cells[4].Value;

        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            var consulta = bd.Products.Where(p => p.ProductID.Equals(txtID.Text));
            foreach(Product oProduct in consulta)
            {
                oProduct.ProductName = txtnombre.Text;
                oProduct.CategoryID = (int)cboCategoria.SelectedValue;
                oProduct.SupplierID = (int)cboProveedor.SelectedValue;
                oProduct.UnitPrice = txtprecio.Value;
                oProduct.UnitsInStock = (short) txtstock.Value;
            }
            try
            {
                bd.SubmitChanges();
                listar();
                MessageBox.Show("Se actualizar correctamente");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocurrio un error");
            }
        }
    }
}
