﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Form2_Load(object sender, EventArgs e)
        {
            cboRegion.DataSource = bd.Regions;
            cboRegion.DisplayMember = "RegionDescription";
            cboRegion.ValueMember = "RegionID";
            listar();
        }

        private void filtrar(object sender, EventArgs e)
        {
            int id = (int)cboRegion.SelectedValue;
            dgvTerritory.DataSource = from region in bd.Regions
                     join territory in bd.Territories
                     on region.RegionID equals territory.RegionID
                     where region.RegionID.Equals(id)
                     select new { nombre = territory.TerritoryDescription, region = region.RegionDescription };
        }
        private void listar()
        {
            dgvTerritory.DataSource = from region in bd.Regions
                     join territory in bd.Territories
                    on region.RegionID equals territory.RegionID
                   select new { nombre = territory.TerritoryDescription, region = region.RegionDescription };
        }
    }
}
