﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string id = txtTerritoryID.Text;
            string nombre = txtTerritoryName.Text;
            int idRegion = int.Parse(cboRegion.SelectedValue.ToString());
            //Que no sea vacio
            if (id.Equals(""))
            {
                errorDatos.SetError(txtTerritoryID, "Debe ingresar el ID del territorio");
                return;
            }
            else
            {
                errorDatos.SetError(txtTerritoryID, "");
            }

            if (nombre.Equals(""))
            {
                errorDatos.SetError(txtTerritoryName, "Debe ingresar el nombre del territorio");
                return;
            }
            else
            {
                errorDatos.SetError(txtTerritoryName, "");
            }
         
            //id unico
            int numeroID = (from territory in bd.Territories
                            where territory.TerritoryID.Equals(id)
                            select territory).Count();
            if (numeroID == 1)
            {
                MessageBox.Show("Ya existe el ID en la base de datos");
                return;
            }
            //nombre unico
            int numeroNombre = (from territory in bd.Territories
                                where territory.TerritoryDescription.Equals(nombre)
                                select territory).Count();

            if (numeroNombre == 1)
            {
                MessageBox.Show("Ya existe el nombre en la base de datos");
                return;
            }
    
            Territory oTerritory = new Territory
            {
                TerritoryID = id,
                TerritoryDescription = nombre,
                RegionID = idRegion
            };
            bd.Territories.InsertOnSubmit(oTerritory);
            try
            {
                bd.SubmitChanges();
                listar();
                MessageBox.Show("Se registro correctamente");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrio un error");
            }
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Form3_Load(object sender, EventArgs e)
        {
            listar();
            cboRegion.DataSource = bd.Regions;
            cboRegion.DisplayMember = "RegionDescription";
            cboRegion.ValueMember = "RegionID";
        }
        private void listar()
        {

            dgvTerritory.DataSource = from territory in bd.Territories
                                      join region in bd.Regions
                                      on territory.RegionID equals region.RegionID
                                      select new
                                      {
                                          territory.TerritoryDescription,
                                          region.RegionDescription
                                      };

        }

    }
}
