﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Form2_Load(object sender, EventArgs e)
        {
            cboCategoria.DataSource = bd.Categories;
            cboCategoria.DisplayMember = "CategoryName";
            cboCategoria.ValueMember = "CategoryID";
            listar();
        }
        private void listar()
        {
            dgvProducto.DataSource= from p in bd.Products
                                    join c in bd.Categories
                                    on p.CategoryID equals c.CategoryID
                                    select new { p.ProductName, c.CategoryName ,p.UnitsInStock };
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            dgvProducto.DataSource = from p in bd.Products
                                     join c in bd.Categories
                                     on p.CategoryID equals c.CategoryID
                                     where p.CategoryID.Equals(cboCategoria.SelectedValue)
                                     select new { p.ProductName, c.CategoryName, p.UnitsInStock };
        }
    }
}
