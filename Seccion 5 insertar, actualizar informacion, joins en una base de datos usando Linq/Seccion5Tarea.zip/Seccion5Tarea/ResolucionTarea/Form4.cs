﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void listar()
        {

            dgvTerritory.DataSource = from territory in bd.Territories
                                      select new
                                      {
                                          territory.TerritoryID,
                                          territory.TerritoryDescription,
                                          territory.RegionID
                                      };

        }
        private void Form4_Load(object sender, EventArgs e)
        {
            listar();
            cboRegion.DataSource = bd.Regions;
            cboRegion.DisplayMember = "RegionDescription";
            cboRegion.ValueMember = "RegionID";
        }

        private void obtenerDatos(object sender, DataGridViewCellEventArgs e)
        {
            string Idterritory = dgvTerritory.CurrentRow.Cells[0].Value.ToString();
            string nombre = dgvTerritory.CurrentRow.Cells[1].Value.ToString();
            int idRegion = (int)dgvTerritory.CurrentRow.Cells[2].Value;
            txtTerritoryID.Text = Idterritory;
            txtTerritoryName.Text = nombre;
            cboRegion.SelectedValue = idRegion;
           
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            var consulta = bd.Territories.Where(p => p.TerritoryID.Equals(txtTerritoryID.Text));
            if (txtTerritoryName.Text.Equals(""))
            {
                errorDato.SetError(txtTerritoryName, "No puede ser vacio el nombre del territorio");
                return;
            }
            else
            {
                errorDato.SetError(txtTerritoryName, "");
            }
            foreach (Territory oTerritory in consulta)
            {
                oTerritory.TerritoryID =txtTerritoryID.Text;
                oTerritory.TerritoryDescription = txtTerritoryName.Text;
                oTerritory.RegionID = (int)cboRegion.SelectedValue;
            }
            try
            {
                bd.SubmitChanges();
                listar();
                MessageBox.Show("Se actualizo correctamente");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrio un error");
            }
        }
    }
}
