﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NuestraTerceraAplicacion
{
    public partial class frmPopupTerritorio : Form
    {
        public string accion { get; set; }
        public string id { get; set; }
        public frmPopupTerritorio()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void frmPopupTerritorio_Load(object sender, EventArgs e)
        {
            if (accion.Equals("Nuevo"))
            {
                this.Text = "Ingrese territorio";
            }
            else
            {
                this.Text = "Editar territorio";
                var consulta = bd.Territories.Where(p => p.TerritoryID.Equals(id));
                foreach(Territories ter in consulta)
                {
                    txtId.Text = ter.TerritoryID;
                    txtnombre.Text = ter.TerritoryDescription;
                    cboRegion.SelectedValue = ter.RegionID;
                }
            }


            cboRegion.DataSource = bd.Region.ToList();
            cboRegion.DisplayMember = "RegionDescription";
            cboRegion.ValueMember = "RegionId";
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {

            if (txtnombre.Text.Equals(""))
            {
                errorData.SetError(txtnombre, "Ingrese nombre");
                this.DialogResult = DialogResult.None;
                return;
            }else
            {
                errorData.SetError(txtnombre, "");
            }

            if (txtId.Text.Equals(""))
            {
                errorData.SetError(txtId, "Ingrese codigo o Id");
                this.DialogResult = DialogResult.None;
                return;
            }
            else
            {
                errorData.SetError(txtId, "");
            }

            if (accion.Equals("Nuevo"))
            {

                //Una insercion
                string id = txtId.Text;
                string nombre = txtnombre.Text;
                int idregion =int.Parse( cboRegion.SelectedValue.ToString());
                Territories ter = new Territories
                {
                    TerritoryID=id,
                    TerritoryDescription=nombre,
                    RegionID=idregion,
                    bhabilitado=true
                };
                bd.Territories.InsertOnSubmit(ter);
                try
                {
                    bd.SubmitChanges();
                    MessageBox.Show("Se agrego correctamente");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");
                }

            }
            else{
                //Edicion de los valores
                var consulta = bd.Territories.Where(p => p.TerritoryID.Equals(id));
                foreach(Territories ter in consulta)
                {
                    ter.TerritoryDescription = txtnombre.Text;
                    ter.RegionID = int.Parse(cboRegion.SelectedValue.ToString());
                }
                try
                {
                    bd.SubmitChanges();
                    MessageBox.Show("Se edito correctamente");
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");

                }
            }
        }
    }
}
