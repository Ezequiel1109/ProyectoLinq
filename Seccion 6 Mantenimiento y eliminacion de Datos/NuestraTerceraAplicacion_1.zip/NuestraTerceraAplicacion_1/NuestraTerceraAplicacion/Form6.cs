﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NuestraTerceraAplicacion
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        PruebaDataContext bd=new PruebaDataContext();
        private void Form6_Load(object sender, EventArgs e)
        {
            listar();
        }

        private void listar()
        {
            dgvEmpleado.DataSource = bd.Employees.Where(p => p.bhabilitado.Equals(1)).ToList();
        }

        private void filtrar(object sender, EventArgs e)
        {
            string nombre = txtnombre.Text;
            dgvEmpleado.DataSource = bd.Employees.Where(p => p.bhabilitado.Equals(1)).Where(x => x.FirstName.Contains(nombre)).ToList();
        }

        private void toolStripLabel3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Desea eliminar?", "Aviso", MessageBoxButtons.YesNo).Equals(DialogResult.Yes))
            {
                string id = dgvEmpleado.CurrentRow.Cells[0].Value.ToString();
                var consulta = bd.Employees.Where(p => p.EmployeeID.Equals(id));
                foreach (Employees emp in consulta)
                {
                    emp.bhabilitado = false;
                }
                try
                {
                    bd.SubmitChanges();
                    listar();
                    MessageBox.Show("Se elimino correctamente");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");
                }
            }


        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            frmPopupEmpleado ofrmPopupEmpleado = new frmPopupEmpleado();
            ofrmPopupEmpleado.accion = "Nuevo";
            ofrmPopupEmpleado.ShowDialog();
            if (ofrmPopupEmpleado.DialogResult.Equals(DialogResult.OK))
            {
                listar();
            }



               }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            frmPopupEmpleado ofrmPopupEmpleado = new frmPopupEmpleado();
            ofrmPopupEmpleado.accion = "Editar";
            ofrmPopupEmpleado.id = dgvEmpleado.CurrentRow.Cells[0].Value.ToString();
            ofrmPopupEmpleado.txtCOdigo.ReadOnly = true;
            ofrmPopupEmpleado.ShowDialog();
            if (ofrmPopupEmpleado.DialogResult.Equals(DialogResult.OK))
            {
                listar();
            }
        }
    }
}
