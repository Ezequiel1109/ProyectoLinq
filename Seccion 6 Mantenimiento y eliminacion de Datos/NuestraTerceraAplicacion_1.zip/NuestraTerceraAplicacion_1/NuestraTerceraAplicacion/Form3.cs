﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NuestraTerceraAplicacion
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Form3_Load(object sender, EventArgs e)
        {
            listar();
        }

        private void listar()
        {
            //Activos son aquellos que tienen bhabilitado=1
            dgvRegion.DataSource = bd.Region.Where(p => p.bhabilitado.Equals(1)).Select(x => new { x.RegionID, x.RegionDescription }).ToList();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            //Obtener el registro de la bd
            if(MessageBox.Show("¿Desea eliminar?","Aviso", MessageBoxButtons.YesNo).Equals(DialogResult.Yes))
            {
                string idRegion = dgvRegion.CurrentRow.Cells[0].Value.ToString();
                var consulta = bd.Region.Where(p => p.RegionID.Equals(idRegion));
                foreach(Region reg in consulta)
                {
                    reg.bhabilitado = false;
                }

                try
                {
                    bd.SubmitChanges();
                    listar();
                    MessageBox.Show("Se elimino correctamente");
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");
                }


            }
         

        }



  
    }
}
