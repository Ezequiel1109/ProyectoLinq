﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NuestraTerceraAplicacion
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            frmPopupTerritorio ofrmPopupTerritorio = new frmPopupTerritorio();
            //Asignar valor
            ofrmPopupTerritorio.accion = "Nuevo";

            ofrmPopupTerritorio.ShowDialog();
            if (ofrmPopupTerritorio.DialogResult.Equals(DialogResult.OK))
            {
                listar();
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            listar();
        }
        PruebaDataContext bd = new PruebaDataContext();

        private void listar()
        {
            dgvTerritorio.DataSource = bd.Territories.Where(x=>x.bhabilitado.Equals(1)).Select(p => new { p.TerritoryID, p.TerritoryDescription });

        }

        private void filtrar(object sender, EventArgs e)
        {
            string valor = txtnombre.Text;
            dgvTerritorio.DataSource = bd.Territories.Where(p => p.TerritoryDescription.Contains(valor)).ToList();
        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            frmPopupTerritorio ofrmPopupTerritorio = new frmPopupTerritorio();
            ofrmPopupTerritorio.accion = "Editar";
            ofrmPopupTerritorio.id = id;
            ofrmPopupTerritorio.txtId.ReadOnly = true;
            ofrmPopupTerritorio.ShowDialog();
            if (ofrmPopupTerritorio.DialogResult.Equals(DialogResult.OK))
            {
                listar();
            }
        }
        string id;
        private void obtenerID(object sender, DataGridViewCellEventArgs e)
        {
             id = dgvTerritorio.CurrentRow.Cells[0].Value.ToString();
        }

        private void toolStripLabel3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("ELiminar?", "Aviso", MessageBoxButtons.YesNo).Equals(DialogResult.Yes)) { 
            var consulta = bd.Territories.Where(p => p.TerritoryID.Equals(id));
            foreach(Territories ter in consulta)
            {
                ter.bhabilitado = false;
            }
            try
            {
                bd.SubmitChanges();
                listar();
                MessageBox.Show("Se elimino correctamente");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocurrio un error");
            }
        }
    }

        private void toolStripLabel4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
