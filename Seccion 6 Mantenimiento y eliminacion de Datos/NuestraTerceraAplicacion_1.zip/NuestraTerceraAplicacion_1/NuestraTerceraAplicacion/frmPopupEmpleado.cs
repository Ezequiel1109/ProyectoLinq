﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NuestraTerceraAplicacion
{
    public partial class frmPopupEmpleado : Form
    {
        public string accion { get; set; }
        public string id { get; set; }
        public frmPopupEmpleado()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void frmPopupEmpleado_Load(object sender, EventArgs e)
        {
            if (!accion.Equals("Nuevo"))
            {
                var consulta = bd.Employees.Where(p => p.EmployeeID.Equals(id));
                foreach(Employees emp in consulta){
                    txtCOdigo.Text = emp.EmployeeID.ToString();
                    txtdireccion.Text = emp.Address;
                    txtfecha.Value =DateTime.Parse( emp.BirthDate.ToString());
                    txtlastname.Text = emp.LastName;
                    txttitulo.Text = emp.Title;
                    txtfirstname.Text = emp.FirstName;
                }
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (txtCOdigo.Text.Equals(""))
            {
                errorData.SetError(txtCOdigo, "Ingrese codigo");
                this.DialogResult = DialogResult.None;
                return;
            }
            else
            {
                //Asi se borra
                errorData.SetError(txtCOdigo, "");
            }

            if (txtfirstname.Text.Equals(""))
            {
                errorData.SetError(txtfirstname, "Ingrese first name");
                this.DialogResult = DialogResult.None;
                return;
            }
            else
            {
                //Asi se borra
                errorData.SetError(txtfirstname, "");
            }

            if (txtlastname.Text.Equals(""))
            {
                errorData.SetError(txtlastname, "Ingrese Last Name");
                this.DialogResult = DialogResult.None;
                return;
            }
            else
            {
                //Asi se borra
                errorData.SetError(txtlastname, "");
            }

            if (txttitulo.Text.Equals(""))
            {
                errorData.SetError(txttitulo, "Ingrese Titulo");
                this.DialogResult = DialogResult.None;
                return;
            }
            else
            {
                //Asi se borra
                errorData.SetError(txttitulo, "");
            }

            string firstName = txtfirstname.Text;
            string lastName = txtlastname.Text;
            string direccion = txtdireccion.Text;
            string titulo = txttitulo.Text;
            DateTime fecha = txtfecha.Value;
            if (accion.Equals("Nuevo"))
            {
                //Insercion
                int codigo =int.Parse( txtCOdigo.Text);
               
                Employees em = new Employees()
                {
                    EmployeeID = codigo,
                    FirstName = firstName,
                    LastName = lastName,
                    Address = direccion,
                    Title = titulo,
                    BirthDate = fecha,
                    bhabilitado=true
                };
                bd.Employees.InsertOnSubmit(em);
                try
                {
                    bd.SubmitChanges();
                    MessageBox.Show("Se agrego correctamente");
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");

                }



            }
            else
            {
                var consulta = bd.Employees.Where(p => p.EmployeeID.Equals(id));
                foreach(Employees emp in consulta)
                {
                    emp.FirstName = firstName;
                    emp.LastName = lastName;
                    emp.Title = titulo;
                    emp.BirthDate = fecha;
                    emp.Address = direccion;
                }
                try
                {
                    bd.SubmitChanges();
                    MessageBox.Show("Se edito correctamente");
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");

                }

            }
        }
    }
}
