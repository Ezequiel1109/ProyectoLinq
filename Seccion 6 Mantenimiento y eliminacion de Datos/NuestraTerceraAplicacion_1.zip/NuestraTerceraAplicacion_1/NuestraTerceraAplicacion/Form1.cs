﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NuestraTerceraAplicacion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Form1_Load(object sender, EventArgs e)
        {
            listar();
        }
        private void listar()
        {
            dgvRegion.DataSource = bd.Region.ToList();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Desea eliminar?", "Aviso", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string idRegion = dgvRegion.CurrentRow.Cells[0].Value.ToString();
                var consulta = bd.Region.Where(p => p.RegionID.Equals(idRegion));
                foreach(Region reg in consulta)
                {
                    bd.Region.DeleteOnSubmit(reg);
                }
                try
                {
                    bd.SubmitChanges();
                    listar();
                    MessageBox.Show("Se elimino correctamente");
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");
                }


            }
       
        }

        
    }
}
