﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NuestraTerceraAplicacion
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            listar();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void listar()
        {
            dgvTerritories.DataSource = bd.Territories.Where(p => p.bhabilitado.Equals(1)).ToList();
        }
      

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("¿Desea eliminar?", "Aviso", MessageBoxButtons.YesNo).Equals(DialogResult.Yes))
            {
                string idTerritorio = dgvTerritories.CurrentRow.Cells[0].Value.ToString();
                var consulta = bd.Territories.Where(p => p.TerritoryID.Equals(idTerritorio));
                foreach(var item in consulta)
                {
                    item.bhabilitado = false;
                }
                try
                {
                    bd.SubmitChanges();
                    listar();
                    MessageBox.Show("Se elimino correctamente");
                }catch(Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");
                }


            }

            }
        }
    }

