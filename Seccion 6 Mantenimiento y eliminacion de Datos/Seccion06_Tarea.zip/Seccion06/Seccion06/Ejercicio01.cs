﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seccion06
{
    public partial class Ejercicio01 : Form
    {
     
        public Ejercicio01()
        {
            InitializeComponent();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Ejercicio01_Load(object sender, EventArgs e)
        {
            listar();
        }
        private void listar()
        {
            dgvProducto.DataSource = from supplier in bd.Suppliers
                                     join producto in bd.Products
                                     on supplier.SupplierID equals producto.SupplierID
                                     join categoria in bd.Categories
                                      on producto.CategoryID equals categoria.CategoryID
                                     where producto.bhabilitado.Equals(true)
                                     select new {producto.ProductID, producto.ProductName ,  categoria.CategoryName,  supplier.CompanyName };
        }

        private void filtrar(object sender, EventArgs e)
        {

            dgvProducto.DataSource = from supplier in bd.Suppliers
                                     join producto in bd.Products
                                     on supplier.SupplierID equals producto.SupplierID
                                     join categoria in bd.Categories
                                      on producto.CategoryID equals categoria.CategoryID
                                     where producto.ProductName.Contains(txtnombre.Text)
                                     select new { producto.ProductID, producto.ProductName, categoria.CategoryName, supplier.CompanyName };
           
        }

   
   

        private void toolStripNuevo_Click(object sender, EventArgs e)
        {
            frmPopup ofrmPopup = new frmPopup();
            ofrmPopup.accion = "Nuevo";
            ofrmPopup.ShowDialog();
            if (ofrmPopup.DialogResult.Equals(DialogResult.OK))
            {
                listar();
            }
        }

        private void toolStripEditar_Click(object sender, EventArgs e)
        {
            frmPopup ofrmPopup = new frmPopup();
            ofrmPopup.accion = "Editar";
            ofrmPopup.idProducto = (int)(dgvProducto.CurrentRow.Cells[0].Value);
            ofrmPopup.ShowDialog();
            if (ofrmPopup.DialogResult.Equals(DialogResult.OK))
            {
                listar();
            }
        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Desea eliminar?", "Eliminacion", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                string id = dgvProducto.CurrentRow.Cells[0].Value.ToString();
                var consulta = bd.Products.Where(p => p.ProductID.Equals(id));
                foreach (var item in consulta)
                {
                    item.bhabilitado = false;
                }
                try
                {
                    bd.SubmitChanges();
                    listar();
                    MessageBox.Show("Se elimino correctamente");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");
                }
            }
        }
    }
}
