﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seccion06
{
    public partial class frmPopup : Form
    {
        public string accion { get; set; }
        public int idProducto { get; set; }
        public frmPopup()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();

        private void frmPopup_Load(object sender, EventArgs e)
        {
            cboCategoria.DataSource = bd.Categories;
            cboCategoria.DisplayMember = "CategoryName";
            cboCategoria.ValueMember = "CategoryID";
            cboProveedor.DataSource = bd.Suppliers;
            cboProveedor.DisplayMember = "CompanyName";
            cboProveedor.ValueMember = "SupplierID";
            if (accion.Equals("Nuevo"))
            {
                this.Text = "Agregar un nuevo producto";
            }
            else
            {
                this.Text = "Editar un producto";
                var consulta = bd.Products.Where(p => p.ProductID.Equals(idProducto));
                foreach(var item in consulta)
                {
                    txtID.Text = item.ProductID.ToString();
                    txtnombre.Text = item.ProductName;
                    cboCategoria.SelectedValue = item.CategoryID;
                    cboProveedor.SelectedValue = item.SupplierID;
                }
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string nombre = txtnombre.Text;
            int idProveedor =(int) cboProveedor.SelectedValue;
            int idCategoria= (int)cboCategoria.SelectedValue;
            if (nombre.Equals(""))
            {
                errorProducto.SetError(txtnombre, "Debe ingresar el nombre");
                this.DialogResult = DialogResult.None;
                return;
            }
            else
            {
                errorProducto.SetError(txtnombre, "");
            }
            if (accion.Equals("Nuevo"))
            {
                //Validamos que el producto ingresado no exista en  la base de datos
                int numeroVeces = (bd.Products.Where(p => p.ProductName.Equals(nombre))).Count();
                if (numeroVeces == 1)
                {
                    MessageBox.Show("Existe el nombre del producto en la base de datos");
                    this.DialogResult = DialogResult.None;
                    return;
                }
                Products oProducts = new Products()
                {
                    ProductName = nombre,
                    SupplierID = idProveedor,
                    CategoryID = idCategoria,
                    bhabilitado=true
                };
                bd.Products.InsertOnSubmit(oProducts);
                try
                {
                    bd.SubmitChanges();
                    MessageBox.Show("Se registro correctamente");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");
                }
            }
            else
            {
                var consulta = bd.Products.Where(p => p.ProductID.Equals(idProducto));
                foreach(var item in consulta)
                {
                    item.ProductName = nombre;
                    item.CategoryID = idCategoria;
                    item.SupplierID = idProveedor;
                }
                try
                {
                    bd.SubmitChanges();
                    MessageBox.Show("Se actualizo correctamente");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrio un error");
                }
            }
         
        }
    }
}
