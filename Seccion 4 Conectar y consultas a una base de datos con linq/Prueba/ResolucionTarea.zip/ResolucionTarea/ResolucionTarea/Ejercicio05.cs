﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Ejercicio05 : Form
    {
        public Ejercicio05()
        {
            InitializeComponent();
        }
        PruebaDataContext bd = new PruebaDataContext();
        private void Ejercicio05_Load(object sender, EventArgs e)
        {
            listar();
        }
        private void listar()
        {
            dgvEmpleado.DataSource = bd.ALUMNO.
                Select(p => new { nombre = p.NOMBREALUMNO, suma = p.NOTA1 + p.NOTA2 + p.NOTA3 + p.NOTA4 });
        }
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            dgvEmpleado.DataSource = bd.ALUMNO.
                Select(p => new { nombre = p.NOMBREALUMNO, suma = p.NOTA1 + p.NOTA2 + p.NOTA3 + p.NOTA4 })
                .Where(x => x.suma > txtnumero1.Value && x.suma < txtnumero2.Value);
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            listar();
            txtnumero1.Value = 0;
            txtnumero2.Value = 0;
        }
    }
}
