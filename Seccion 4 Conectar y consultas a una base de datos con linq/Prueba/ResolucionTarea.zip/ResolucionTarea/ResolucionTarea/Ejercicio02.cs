﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Ejercicio02 : Form
    {
        public Ejercicio02()
        {
            InitializeComponent();
        }

        private void Ejercicio02_Load(object sender, EventArgs e)
        {
            PruebaDataContext db = new PruebaDataContext();
            dgvEmpleado.DataSource = db.ALUMNO.Select(p => new
            {
                nombreCompleto = p.NOMBREALUMNO + " " + p.APELLIDOPATERNOALUMNO + " " + p.APELLIDOMATERNOALUMNO,
                promedio = (p.NOTA1 + p.NOTA2 + p.NOTA3 + p.NOTA4) / 4.0
            });
        }
    }
}
