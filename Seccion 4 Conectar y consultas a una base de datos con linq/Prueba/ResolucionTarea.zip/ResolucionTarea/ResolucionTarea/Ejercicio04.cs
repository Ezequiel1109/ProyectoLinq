﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Ejercicio04 : Form
    {
        public Ejercicio04()
        {
            InitializeComponent();
        }

        private void Ejercicio04_Load(object sender, EventArgs e)
        {
            listarEmpleados();
        }
        PruebaDataContext db = new PruebaDataContext();
        private void listarEmpleados()
        {
            dgvEmpleado.DataSource = db.ALUMNO.Select(p=>new {
            nombre=p.NOMBREALUMNO , apPat=p.APELLIDOPATERNOALUMNO , apMat=p.APELLIDOMATERNOALUMNO,fav=p.CURSOFAVORITO
            });
        }

        private void filtrar(object sender, EventArgs e)
        {
            string grado = txtnombre.Text;
            dgvEmpleado.DataSource = db.ALUMNO.Where(x=>x.NIVELACADEMICO.Contains(grado)).Select(p => new {
                nombre = p.NOMBREALUMNO,
                apPat = p.APELLIDOPATERNOALUMNO,
                apMat = p.APELLIDOMATERNOALUMNO,
                fav = p.CURSOFAVORITO
            });
        }
    }
}
