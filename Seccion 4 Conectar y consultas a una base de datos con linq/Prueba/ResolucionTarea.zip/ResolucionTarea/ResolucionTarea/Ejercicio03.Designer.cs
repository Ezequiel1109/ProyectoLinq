﻿namespace ResolucionTarea
{
    partial class Ejercicio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvEmpleados = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIds = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.btnLimpiars = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvEmpleados
            // 
            this.dgvEmpleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpleados.Location = new System.Drawing.Point(24, 73);
            this.dgvEmpleados.Name = "dgvEmpleados";
            this.dgvEmpleados.Size = new System.Drawing.Size(747, 336);
            this.dgvEmpleados.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(114, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "ID";
            // 
            // txtIds
            // 
            this.txtIds.Location = new System.Drawing.Point(191, 26);
            this.txtIds.Name = "txtIds";
            this.txtIds.Size = new System.Drawing.Size(223, 20);
            this.txtIds.TabIndex = 3;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(452, 26);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(75, 23);
            this.btnBuscar.TabIndex = 4;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // btnLimpiars
            // 
            this.btnLimpiars.Location = new System.Drawing.Point(565, 26);
            this.btnLimpiars.Name = "btnLimpiars";
            this.btnLimpiars.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiars.TabIndex = 5;
            this.btnLimpiars.Text = "Limpiar";
            this.btnLimpiars.UseVisualStyleBackColor = true;
            this.btnLimpiars.Click += new System.EventHandler(this.btnLimpiars_Click);
            // 
            // Ejercicio03
            // 
            this.ClientSize = new System.Drawing.Size(795, 425);
            this.Controls.Add(this.btnLimpiars);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.txtIds);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvEmpleados);
            this.Name = "Ejercicio03";
            this.Load += new System.EventHandler(this.Ejercicio03_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvEmpleado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.DataGridView dgvEmpleados;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIds;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnLimpiars;
    }
}