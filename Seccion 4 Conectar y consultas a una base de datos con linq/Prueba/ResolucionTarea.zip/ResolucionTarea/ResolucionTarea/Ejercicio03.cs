﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResolucionTarea
{
    public partial class Ejercicio03 : Form
    {
        public Ejercicio03()
        {
            InitializeComponent();
        }

      

       
        PruebaDataContext bd = new PruebaDataContext();
        private void listar()
        {
            dgvEmpleados.DataSource = bd.ALUMNO;
        }
        private void Ejercicio03_Load(object sender, EventArgs e)
        {
            listar();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtIds.Text);
            var consulta = bd.ALUMNO.Where(p => p.IDALUMNO == id).Select(
                x => new { nombre = x.NOMBREALUMNO, nota1 = x.NOTA1, nota2 = x.NOTA2, nota3 = x.NOTA3, nota4 = x.NOTA4 }
                );
            dgvEmpleados.DataSource = consulta;
        }

        private void Ejercicio03_Load_1(object sender, EventArgs e)
        {
            listar();
        }

        private void btnLimpiars_Click(object sender, EventArgs e)
        {
            txtIds.Text = "";
            listar();
        }
    }
}
